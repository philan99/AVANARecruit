# AVANA Services AI

Standalone, self-contained version of the AVANA Services AI marketing site.

## Quick start

```bash
pnpm install
pnpm run dev
```

Then open http://localhost:5000

## Build

```bash
pnpm run build
```

The static site is output to `dist/public`.

## Publishing on Replit

1. Create a new Replit (Import from upload, or upload this folder).
2. The included `.replit` file is already set up for Static deployment.
3. Click **Publish** in the workspace.
4. The site will go live at your project's `.replit.app` URL.

## Notes

- The contact form is visual-only and does not submit anywhere.
- No backend, no database, no auth.
- Brand: navy `#1A2035`, green `#4CAF50`, Inter font.
